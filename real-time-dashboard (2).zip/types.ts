export interface RegionalData {
  id: string
  name: string
  population: number
  gdpGrowth: number
  laborForce: number
  averageWage: number
  infrastructureScore: number
  investmentScore: number
  coordinates: [number, number]
}

export interface InvestmentIncentive {
  id: string
  type: "BOI" | "PEZA" | "LGU"
  title: string
  description: string
  requirements: string[]
  benefits: string[]
  region: string
  expiryDate: string
}

export interface RiskMetrics {
  political: number
  economic: number
  infrastructure: number
  workforce: number
  details: {
    political: string[]
    economic: string[]
    infrastructure: string[]
    workforce: string[]
  }
}

export interface InvestmentOpportunity {
  id: string
  sector: string
  region: string
  investmentSize: number
  jobsCreated: number
  incentives: string[]
  description: string
  status: "open" | "pending" | "closed"
}

export interface MarketTrend {
  date: string
  fdi: number
  gdpGrowth: number
  employmentRate: number
}

