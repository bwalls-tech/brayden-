export interface BusinessRequirement {
  id: string
  companyName: string
  industry: string
  investmentSize: number
  employmentTarget: number
  preferredLocations?: string[]
  infrastructureNeeds: {
    power: boolean
    water: boolean
    internet: boolean
    transportation: boolean
    ports: boolean
  }
  workforceNeeds: {
    skilled: number
    unskilled: number
    technical: number
  }
  spaceRequirement: {
    type: "land" | "office" | "industrial"
    size: number // in square meters
  }
  timeline: string
  environmentalFactors: string[]
  additionalRequirements: string[]
  contactPerson: {
    name: string
    position: string
    email: string
    phone: string
  }
}

export interface RegionalProfile {
  id: string
  name: string
  province: string
  population: number
  workforce: {
    skilled: number
    unskilled: number
    technical: number
  }
  infrastructure: {
    power: {
      available: boolean
      capacity: number
      reliability: number
    }
    water: {
      available: boolean
      capacity: number
      quality: number
    }
    internet: {
      available: boolean
      speed: number
      providers: number
    }
    transportation: {
      airports: number
      seaports: number
      highways: number
    }
  }
  landAvailability: {
    industrial: number
    commercial: number
    agricultural: number
  }
  incentives: {
    tax: string[]
    other: string[]
  }
  contacts: {
    government: GovernmentContact[]
    department: DepartmentContact[]
  }
  naturalResources: string[]
  majorIndustries: string[]
  educationalInstitutions: number
  costOfLiving: number
  qualityOfLife: number
}

export interface GovernmentContact {
  id: string
  name: string
  position: string
  department: string
  email: string
  phone: string
  responseTime?: number // in hours
}

export interface DepartmentContact {
  id: string
  name: string
  role: string
  email: string
  phone: string
}

export interface MatchResult {
  id: string
  businessId: string
  regionId: string
  matchScore: number
  matchFactors: {
    factor: string
    score: number
    details: string
  }[]
  status: "pending" | "contacted" | "responded" | "escalated" | "matched" | "rejected"
  timeline: {
    created: string
    contacted?: string
    responded?: string
    escalated?: string
    matched?: string
    rejected?: string
  }
  notes: string[]
}

export interface EmailTemplate {
  type: "business" | "government" | "escalation"
  subject: string
  body: string
  attachments?: string[]
}

