"use client"

import { useEffect, useState } from "react"

import type { InvestmentIncentive, InvestmentOpportunity, MarketTrend, RegionalData, RiskMetrics } from "@/types"
import InvestmentIncentives from "@/components/investment-incentives"
import InvestmentOpportunities from "@/components/investment-opportunities"
import MarketTrends from "@/components/market-trends"
import RegionalMap from "@/components/regional-map"
import RiskAnalysis from "@/components/risk-analysis"

// Simulated data fetching functions
const fetchMockData = () => {
  const regionalData: RegionalData[] = [
    {
      id: "NCR",
      name: "National Capital Region",
      population: 13484462,
      gdpGrowth: 7.2,
      laborForce: 6500000,
      averageWage: 22000,
      infrastructureScore: 85,
      investmentScore: 90,
      coordinates: [14.6091, 120.9876],
    },
    // Add more regions...
  ]

  const incentives: InvestmentIncentive[] = [
    {
      id: "1",
      type: "BOI",
      title: "Tax Holiday for Tech Companies",
      description: "4-6 year income tax holiday for tech companies",
      requirements: ["Minimum investment of $1M", "Create 50 local jobs"],
      benefits: ["Income tax holiday", "Duty-free importation"],
      region: "NCR",
      expiryDate: "2024-12-31",
    },
    // Add more incentives...
  ]

  const riskMetrics: RiskMetrics = {
    political: 75,
    economic: 82,
    infrastructure: 68,
    workforce: 88,
    details: {
      political: ["Stable government", "Strong foreign relations"],
      economic: ["Growing GDP", "Controlled inflation"],
      infrastructure: ["Improving transport", "Digital infrastructure"],
      workforce: ["Young population", "High education rate"],
    },
  }

  const marketTrends: MarketTrend[] = Array.from({ length: 12 }, (_, i) => ({
    date: new Date(2024, i, 1).toISOString(),
    fdi: Math.random() * 1000 + 500,
    gdpGrowth: Math.random() * 3 + 5,
    employmentRate: Math.random() * 10 + 85,
  }))

  const opportunities: InvestmentOpportunity[] = [
    {
      id: "1",
      sector: "Technology",
      region: "NCR",
      investmentSize: 1000000,
      jobsCreated: 100,
      incentives: ["Tax holiday", "Duty-free importation"],
      description: "Tech hub development project",
      status: "open",
    },
    // Add more opportunities...
  ]

  return {
    regionalData,
    incentives,
    riskMetrics,
    marketTrends,
    opportunities,
  }
}

export default function InvestmentDashboard() {
  const [data, setData] = useState<{
    regionalData: RegionalData[]
    incentives: InvestmentIncentive[]
    riskMetrics: RiskMetrics
    marketTrends: MarketTrend[]
    opportunities: InvestmentOpportunity[]
  } | null>(null)

  useEffect(() => {
    const mockData = fetchMockData()
    setData(mockData)
  }, [])

  if (!data) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="mb-6 text-2xl font-bold">Philippines Investment Dashboard</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <RegionalMap
          data={data.regionalData}
          onRegionSelect={(region) => {
            console.log("Selected region:", region)
          }}
        />
        <RiskAnalysis data={data.riskMetrics} />
        <MarketTrends data={data.marketTrends} />
        <InvestmentIncentives incentives={data.incentives} />
        <div className="md:col-span-2">
          <InvestmentOpportunities
            opportunities={data.opportunities}
            onSelect={(opportunity) => {
              console.log("Selected opportunity:", opportunity)
            }}
          />
        </div>
      </div>
    </div>
  )
}

