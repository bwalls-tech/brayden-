import { Suspense } from "react"

import BusinessRequirementsForm from "@/components/business-requirements-form"
import { Card } from "@/components/ui/card"
import type { BusinessRequirement } from "@/types"

export default function Page() {
  return (
    <main className="container mx-auto p-6">
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-8 text-3xl font-bold">Philippines Regional Investment Matching</h1>
        <Suspense fallback={<Card className="h-[400px] animate-pulse" />}>
          <BusinessRequirementsForm
            onSubmit={async (data: BusinessRequirement) => {
              console.log("Form submitted:", data)
              // Implement form submission and matching logic
            }}
          />
        </Suspense>
      </div>
    </main>
  )
}

