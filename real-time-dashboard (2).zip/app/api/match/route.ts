import { NextResponse } from "next/server"
import { OpenAIStream } from "ai"
import { Configuration, OpenAIApi } from "openai-edge"

const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(config)

export async function POST(req: Request) {
  try {
    const { requirement, regions } = await req.json()

    // Create a prompt for the AI to analyze the match
    const prompt = `
      Analyze the following business requirement and regional profiles to find the best matches:

      Business Requirement:
      ${JSON.stringify(requirement, null, 2)}

      Regional Profiles:
      ${JSON.stringify(regions, null, 2)}

      Provide a detailed analysis of the top 5 matching regions, including:
      1. Match score (0-100)
      2. Key matching factors
      3. Potential challenges
      4. Recommendations
    `

    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content:
            "You are an AI investment advisor specializing in regional development in the Philippines. Analyze business requirements and regional profiles to find optimal matches.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      stream: true,
    })

    const stream = OpenAIStream(response)
    return new Response(stream)
  } catch (error) {
    console.error("Error in matching:", error)
    return NextResponse.json({ error: "Failed to process matching request" }, { status: 500 })
  }
}

