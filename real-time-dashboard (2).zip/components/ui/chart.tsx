"use client"

import type { TooltipProps } from "recharts"

export function ChartTooltip({ active, payload, label }: TooltipProps<number, string>) {
  if (!active || !payload) return null

  return (
    <div className="rounded-lg border bg-background p-2 shadow-sm">
      <div className="grid grid-cols-2 gap-2">
        <div className="flex flex-col">
          <span className="text-[0.70rem] uppercase text-muted-foreground">{label}</span>
          {payload.map((item) => (
            <span key={item.name} className="font-bold">
              {item.name}: {item.value}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export function ChartTooltipContent({ active, payload, label }: TooltipProps<number, string>) {
  if (!active || !payload) return null

  return (
    <div className="rounded-lg border bg-background p-2 shadow-sm">
      <div className="grid gap-2">
        <div className="flex flex-col">
          <span className="text-[0.70rem] uppercase text-muted-foreground">{label}</span>
          {payload.map((item) => (
            <span key={item.name} className="font-bold text-sm">
              {item.name}: {item.value}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

