"use client"

import { Building2, Mail, Phone } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import type { GovernmentContact } from "@/types"

interface GovernmentContactsProps {
  contacts: GovernmentContact[]
}

export default function GovernmentContacts({ contacts }: GovernmentContactsProps) {
  return (
    <Card>
      <CardHeader className="space-y-4">
        <CardTitle>Government Contacts Directory</CardTitle>
        <div className="flex space-x-4">
          <Select>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dti">Department of Trade and Industry</SelectItem>
              <SelectItem value="doi">Department of Interior</SelectItem>
              <SelectItem value="da">Department of Agriculture</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ncr">National Capital Region</SelectItem>
              <SelectItem value="r1">Region I</SelectItem>
              <SelectItem value="r2">Region II</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4">
        {contacts.map((contact) => (
          <div key={contact.id} className="rounded-lg border p-4 hover:bg-accent">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold">{contact.name}</h3>
                <p className="text-sm text-muted-foreground">{contact.position}</p>
              </div>
              <Badge>{contact.department}</Badge>
            </div>
            <Separator className="my-2" />
            <div className="grid gap-2">
              <div className="flex items-center text-sm">
                <Building2 className="mr-2 h-4 w-4" />
                {contact.office}
              </div>
              <div className="flex items-center text-sm">
                <Mail className="mr-2 h-4 w-4" />
                {contact.email}
              </div>
              <div className="flex items-center text-sm">
                <Phone className="mr-2 h-4 w-4" />
                {contact.phone}
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

