"use client"

import { useEffect, useState } from "react"
import dynamic from "next/dynamic"

import { Card } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { fetchInvestmentAlerts, fetchMarketSentiment, fetchRegionalData, fetchRiskAnalysis } from "@/lib/api"
import type { InvestmentAlert, RegionalData, RiskAnalysis } from "@/types"

// Dynamically import components
const RealTimeAlerts = dynamic(() => import("@/components/real-time-alerts"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const InvestmentAlerts = dynamic(() => import("@/components/investment-alerts"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const RiskAnalysisCard = dynamic(() => import("@/components/risk-analysis-card"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const MarketSentimentChart = dynamic(() => import("@/components/market-sentiment-chart"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const RegionalMap = dynamic(() => import("@/components/regional-map"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const PhilippinesMap = dynamic(() => import("@/components/philippines-map"), {
  ssr: false,
  loading: () => <Card className="h-[300px] animate-pulse bg-muted" />,
})

const LoadingDashboard = dynamic(() => import("@/components/loading-states"), {
  ssr: false,
})

const ErrorState = dynamic(() => import("@/components/empty-states"), {
  ssr: false,
})

export default function RealTimeDashboard() {
  const [regionalData, setRegionalData] = useState<RegionalData | null>(null)
  const [investmentAlerts, setInvestmentAlerts] = useState<InvestmentAlert[]>([])
  const [riskAnalysis, setRiskAnalysis] = useState<RiskAnalysis | null>(null)
  const [marketSentiment, setMarketSentiment] = useState<number[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [regional, alerts, risk, sentiment] = await Promise.all([
          fetchRegionalData("NCR"),
          fetchInvestmentAlerts(),
          fetchRiskAnalysis("NCR"),
          fetchMarketSentiment(),
        ])
        setRegionalData(regional)
        setInvestmentAlerts(alerts)
        setRiskAnalysis(risk)
        setMarketSentiment(sentiment)
      } catch (err) {
        setError("Failed to load real-time data. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return <LoadingDashboard />
  }

  if (error) {
    return <ErrorState title="Error loading dashboard" description={error} />
  }

  return (
    <TooltipProvider>
      <div className="grid gap-6 p-6 md:grid-cols-2 lg:grid-cols-3">
        <RealTimeAlerts />
        <InvestmentAlerts alerts={investmentAlerts} />
        <RiskAnalysisCard
          data={
            riskAnalysis || {
              political: 0,
              crime: 0,
              economy: 0,
              details: { political: [], crime: [], economy: [] },
              lastUpdated: "",
            }
          }
        />
        <MarketSentimentChart data={marketSentiment} />
        <Tooltip>
          <TooltipTrigger asChild>
            <div>
              <RegionalMap data={regionalData?.regions || []} onRegionSelect={() => {}} />
            </div>
          </TooltipTrigger>
          <TooltipContent>Click on a region to view details</TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <div>
              <PhilippinesMap
                provinces={regionalData?.provinces || []}
                opportunities={regionalData?.opportunities || []}
                onProvinceSelect={() => {}}
                onOpportunitySelect={() => {}}
              />
            </div>
          </TooltipTrigger>
          <TooltipContent>Click on a province to view investment opportunities</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  )
}

