"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { ArrowRight } from "lucide-react"
import * as z from "zod"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import type { BusinessRequirement } from "@/types"

const formSchema = z.object({
  companyName: z.string().min(2, "Company name is required"),
  industry: z.string().min(2, "Industry is required"),
  investmentSize: z.number().min(100000, "Minimum investment is $100,000"),
  employmentTarget: z.number().min(1, "Employment target is required"),
  infrastructureNeeds: z.object({
    power: z.boolean(),
    water: z.boolean(),
    internet: z.boolean(),
    transportation: z.boolean(),
    ports: z.boolean(),
  }),
  workforceNeeds: z.object({
    skilled: z.number(),
    unskilled: z.number(),
    technical: z.number(),
  }),
  spaceRequirement: z.object({
    type: z.enum(["land", "office", "industrial"]),
    size: z.number(),
  }),
  timeline: z.string(),
  environmentalFactors: z.array(z.string()),
  additionalRequirements: z.array(z.string()),
  contactPerson: z.object({
    name: z.string(),
    position: z.string(),
    email: z.string().email(),
    phone: z.string(),
  }),
})

interface BusinessRequirementsFormProps {
  onSubmit: (data: BusinessRequirement) => void
}

export default function BusinessRequirementsForm({ onSubmit }: BusinessRequirementsFormProps) {
  const [step, setStep] = useState(1)
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      infrastructureNeeds: {
        power: false,
        water: false,
        internet: false,
        transportation: false,
        ports: false,
      },
      workforceNeeds: {
        skilled: 0,
        unskilled: 0,
        technical: 0,
      },
    },
  })

  const nextStep = () => setStep((prev) => prev + 1)
  const prevStep = () => setStep((prev) => prev - 1)

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="space-y-6">
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Company Information</CardTitle>
                <CardDescription>Tell us about your company and investment plans</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="companyName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter company name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="industry"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Industry</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select industry" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="manufacturing">Manufacturing</SelectItem>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="agriculture">Agriculture</SelectItem>
                          <SelectItem value="tourism">Tourism</SelectItem>
                          <SelectItem value="energy">Energy</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="investmentSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Investment Size (USD)</FormLabel>
                      <FormControl>
                        <div className="flex items-center space-x-4">
                          <Slider
                            min={100000}
                            max={10000000}
                            step={100000}
                            value={[field.value]}
                            onValueChange={([value]) => field.onChange(value)}
                          />
                          <span className="min-w-[100px] text-right">
                            {new Intl.NumberFormat("en-US", {
                              style: "currency",
                              currency: "USD",
                              maximumFractionDigits: 0,
                            }).format(field.value)}
                          </span>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter className="justify-end">
                <Button onClick={nextStep}>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          )}

          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Infrastructure & Workforce</CardTitle>
                <CardDescription>Specify your infrastructure and workforce requirements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">Infrastructure Needs</h3>
                  {Object.keys(form.getValues().infrastructureNeeds).map((need) => (
                    <FormField
                      key={need}
                      control={form.control}
                      name={`infrastructureNeeds.${need}`}
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between">
                          <FormLabel className="capitalize">{need}</FormLabel>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="font-medium">Workforce Requirements</h3>
                  {Object.entries(form.getValues().workforceNeeds).map(([type, value]) => (
                    <FormField
                      key={type}
                      control={form.control}
                      name={`workforceNeeds.${type}`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="capitalize">{type}</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={0}
                              {...field}
                              onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </CardContent>
              <CardFooter className="justify-between">
                <Button variant="outline" onClick={prevStep}>
                  Previous
                </Button>
                <Button onClick={nextStep}>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          )}

          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
                <CardDescription>Provide contact details and any additional requirements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <FormField
                    control={form.control}
                    name="contactPerson.name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactPerson.position"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Position</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactPerson.email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactPerson.phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="additionalRequirements"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Requirements</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter any additional requirements or preferences"
                          className="h-32"
                          onChange={(e) => field.onChange(e.target.value.split("\n"))}
                        />
                      </FormControl>
                      <FormDescription>Enter each requirement on a new line</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter className="justify-between">
                <Button variant="outline" onClick={prevStep}>
                  Previous
                </Button>
                <Button type="submit">Submit Requirements</Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </form>
    </Form>
  )
}

