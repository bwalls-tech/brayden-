"use client"

import { useEffect, useState } from "react"
import { Bell, Building2, Mail, Phone, Search } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Types
interface Alert {
  id: string
  type: string
  message: string
  time: string
}

interface Contact {
  id: string
  name: string
  position: string
  department: string
  office: string
  email: string
  phone: string
}

interface Project {
  id: string
  title: string
  description: string
  department: string
  budget: number
  progress: number
  status: "planned" | "ongoing" | "completed"
}

// Sample data
const alerts: Alert[] = [
  {
    id: "1",
    type: "Market Update",
    message: "PSEi up by 2.3% in morning trading",
    time: "2 mins ago",
  },
  {
    id: "2",
    type: "Investment Alert",
    message: "New tax incentives announced for tech sector",
    time: "5 mins ago",
  },
  {
    id: "3",
    type: "Regional Update",
    message: "Clark Freeport Zone opens new facilities",
    time: "10 mins ago",
  },
]

const contacts: Contact[] = [
  {
    id: "1",
    name: "Maria Santos",
    position: "Regional Director",
    department: "DTI",
    office: "NCR Regional Office",
    email: "maria.santos@dti.gov.ph",
    phone: "+63 2 8751 0384",
  },
  {
    id: "2",
    name: "Juan Dela Cruz",
    position: "Investment Specialist",
    department: "BOI",
    office: "Central Office",
    email: "juan.delacruz@boi.gov.ph",
    phone: "+63 2 8575 3500",
  },
]

const projects: Project[] = [
  {
    id: "1",
    title: "Clark Green City Development",
    description: "Sustainable urban development project in Clark, Pampanga",
    department: "BCDA",
    budget: 50000000000,
    progress: 45,
    status: "ongoing",
  },
  {
    id: "2",
    title: "Mindanao Railway Project",
    description: "Railway system connecting key cities in Mindanao",
    department: "DOTr",
    budget: 82000000000,
    progress: 25,
    status: "ongoing",
  },
]

export default function Dashboard() {
  const [mounted, setMounted] = useState(false)
  const [selectedDepartment, setSelectedDepartment] = useState<string>("")
  const [investmentSize, setInvestmentSize] = useState<number>(1000000)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="mb-8 text-3xl font-bold">Philippines Investment Portal</h1>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Real-time Alerts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">Real-Time Alerts</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Alert</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {alerts.map((alert) => (
                  <TableRow key={alert.id}>
                    <TableCell className="font-medium">{alert.type}</TableCell>
                    <TableCell>{alert.message}</TableCell>
                    <TableCell>{alert.time}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Investment Matcher */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Investment Matching</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Industry Sector</label>
                <Select onValueChange={(value) => console.log(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sector" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="agriculture">Agriculture</SelectItem>
                    <SelectItem value="tourism">Tourism</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Investment Size (USD)</label>
                <div className="flex items-center space-x-4">
                  <Slider
                    min={100000}
                    max={10000000}
                    step={100000}
                    value={[investmentSize]}
                    onValueChange={([value]) => setInvestmentSize(value)}
                  />
                  <span className="min-w-[100px] text-right">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                      maximumFractionDigits: 0,
                    }).format(investmentSize)}
                  </span>
                </div>
              </div>

              <Button className="w-full" onClick={() => console.log("Matching...")}>
                <Search className="mr-2 h-4 w-4" />
                Find Opportunities
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Project Tracker */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Government Projects</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {projects.map((project) => (
                  <div key={project.id} className="rounded-lg border p-4 hover:bg-accent">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold">{project.title}</h3>
                        <p className="text-sm text-muted-foreground">{project.department}</p>
                      </div>
                      <Badge variant="outline">{project.status}</Badge>
                    </div>
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Budget</span>
                        <span>
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "PHP",
                            maximumFractionDigits: 0,
                          }).format(project.budget)}
                        </span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                      <p className="text-xs text-muted-foreground">Progress: {project.progress}%</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Government Contacts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">Government Contacts</CardTitle>
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Departments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Departments</SelectItem>
                <SelectItem value="DTI">DTI</SelectItem>
                <SelectItem value="BOI">BOI</SelectItem>
                <SelectItem value="PEZA">PEZA</SelectItem>
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {contacts
                  .filter((contact) => !selectedDepartment || contact.department === selectedDepartment)
                  .map((contact) => (
                    <div key={contact.id} className="rounded-lg border p-4 hover:bg-accent">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{contact.name}</h3>
                          <p className="text-sm text-muted-foreground">{contact.position}</p>
                        </div>
                        <Badge>{contact.department}</Badge>
                      </div>
                      <Separator className="my-2" />
                      <div className="grid gap-2">
                        <div className="flex items-center text-sm">
                          <Building2 className="mr-2 h-4 w-4" />
                          {contact.office}
                        </div>
                        <div className="flex items-center text-sm">
                          <Mail className="mr-2 h-4 w-4" />
                          {contact.email}
                        </div>
                        <div className="flex items-center text-sm">
                          <Phone className="mr-2 h-4 w-4" />
                          {contact.phone}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

