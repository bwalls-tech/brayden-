"use client"

import { Gift } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { InvestmentIncentive } from "@/types"

interface InvestmentIncentivesProps {
  incentives: InvestmentIncentive[]
}

export default function InvestmentIncentives({ incentives }: InvestmentIncentivesProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Government Incentives</CardTitle>
        <Gift className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Region</TableHead>
                <TableHead>Expiry</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {incentives.map((incentive) => (
                <TableRow key={incentive.id}>
                  <TableCell>{incentive.type}</TableCell>
                  <TableCell>
                    <Tooltip>
                      <TooltipTrigger className="text-left">{incentive.title}</TooltipTrigger>
                      <TooltipContent>
                        <div className="max-w-xs">
                          <p className="font-medium">Benefits:</p>
                          <ul className="list-disc pl-4 text-sm">
                            {incentive.benefits.map((benefit, index) => (
                              <li key={index}>{benefit}</li>
                            ))}
                          </ul>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TableCell>
                  <TableCell>{incentive.region}</TableCell>
                  <TableCell>{new Date(incentive.expiryDate).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TooltipProvider>
      </CardContent>
    </Card>
  )
}

