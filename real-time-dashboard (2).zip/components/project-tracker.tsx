"use client"

import { useEffect, useState } from "react"
import { Clock, Target } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { GovernmentProject } from "@/types"

interface ProjectTrackerProps {
  projects: GovernmentProject[]
}

export default function ProjectTracker({ projects }: ProjectTrackerProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const getStatusColor = (status: GovernmentProject["status"]) => {
    switch (status) {
      case "planned":
        return "bg-yellow-500"
      case "ongoing":
        return "bg-green-500"
      case "completed":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const calculateProgress = (project: GovernmentProject) => {
    if (!mounted) return 0 // Return 0 during SSR

    const start = new Date(project.startDate).getTime()
    const end = new Date(project.endDate).getTime()
    const now = new Date().getTime()
    const progress = ((now - start) / (end - start)) * 100
    return Math.min(Math.max(progress, 0), 100)
  }

  if (!mounted) {
    return null // Prevent hydration mismatch
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Government Projects</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4">
        {projects.map((project) => (
          <TooltipProvider key={project.id}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="rounded-lg border p-4 hover:bg-accent">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold">{project.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {project.department} - {project.region}
                      </p>
                    </div>
                    <Badge variant="outline">{project.status}</Badge>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <Clock className="mr-2 h-4 w-4" />
                        Timeline
                      </div>
                      <span>
                        {new Date(project.startDate).toLocaleDateString()} -{" "}
                        {new Date(project.endDate).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <Target className="mr-2 h-4 w-4" />
                        Budget
                      </div>
                      <span>
                        {new Intl.NumberFormat("en-US", {
                          style: "currency",
                          currency: "PHP",
                        }).format(project.budget)}
                      </span>
                    </div>
                    <Progress value={calculateProgress(project)} className={getStatusColor(project.status)} />
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">{project.description}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
      </CardContent>
    </Card>
  )
}

