"use client"

import { Award, Mail, MapPin } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { MatchResult, RegionalProfile } from "@/types"

interface MatchResultsProps {
  matches: MatchResult[]
  regions: RegionalProfile[]
  onContactRegion: (match: MatchResult) => void
}

export default function MatchResults({ matches, regions, onContactRegion }: MatchResultsProps) {
  const getRegionName = (regionId: string) => {
    const region = regions.find((r) => r.id === regionId)
    return region ? region.name : "Unknown Region"
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500"
    if (score >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="h-5 w-5" />
          Top Regional Matches
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-6">
            {matches.map((match, index) => (
              <Card key={match.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold">{getRegionName(match.regionId)}</h3>
                      <p className="text-sm text-muted-foreground">
                        Match Score:{" "}
                        <span className={getScoreColor(match.matchScore)}>{match.matchScore.toFixed(1)}%</span>
                      </p>
                    </div>
                    <Badge variant={index < 3 ? "default" : "secondary"}>Rank #{index + 1}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Factor</TableHead>
                        <TableHead>Score</TableHead>
                        <TableHead className="w-[100px]">Rating</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {match.matchFactors.map((factor) => (
                        <TableRow key={factor.factor}>
                          <TableCell className="font-medium">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger className="cursor-help">{factor.factor}</TooltipTrigger>
                                <TooltipContent>
                                  <p className="max-w-xs">{factor.details}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                          <TableCell>{factor.score.toFixed(1)}%</TableCell>
                          <TableCell>
                            <Progress
                              value={factor.score}
                              className={
                                factor.score >= 80
                                  ? "bg-green-500"
                                  : factor.score >= 60
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => {
                        // Open region details
                      }}
                    >
                      <MapPin className="h-4 w-4" />
                      View Details
                    </Button>
                    <Button size="sm" className="gap-2" onClick={() => onContactRegion(match)}>
                      <Mail className="h-4 w-4" />
                      Contact Region
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

