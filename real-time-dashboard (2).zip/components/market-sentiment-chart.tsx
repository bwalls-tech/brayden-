"use client"

import { TrendingUp } from "lucide-react"
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartTooltipContent } from "@/components/ui/chart"

interface MarketSentimentChartProps {
  data: number[]
}

export default function MarketSentimentChart({ data }: MarketSentimentChartProps) {
  // Transform the data array into the format required by recharts
  const chartData = data.map((value, index) => ({
    timestamp: new Date(Date.now() - (data.length - 1 - index) * 3600000).toISOString(),
    sentiment: value,
  }))

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Market Sentiment</CardTitle>
        <TrendingUp className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <XAxis
                dataKey="timestamp"
                tickFormatter={(value) => {
                  return new Date(value).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                }}
              />
              <YAxis />
              <Line type="monotone" dataKey="sentiment" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
              <Tooltip content={<ChartTooltipContent />} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

