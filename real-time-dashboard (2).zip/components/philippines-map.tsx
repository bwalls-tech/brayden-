"use client"

import { Map } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Opportunity, Province } from "@/types"

interface PhilippinesMapProps {
  provinces: Province[]
  opportunities: Opportunity[]
  onProvinceSelect: (province: Province) => void
  onOpportunitySelect: (opportunity: Opportunity) => void
}

export default function PhilippinesMap({
  provinces,
  opportunities,
  onProvinceSelect,
  onOpportunitySelect,
}: PhilippinesMapProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Philippines Investment Map</CardTitle>
        <Map className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="flex h-[300px] items-center justify-center">
          <p className="text-sm text-muted-foreground">Interactive map implementation required</p>
        </div>
      </CardContent>
    </Card>
  )
}

