"use client"

import { useMemo } from "react"
import { Map } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { RegionalData } from "@/types"

interface RegionalMapProps {
  data: RegionalData[]
  onRegionSelect: (region: RegionalData) => void
}

export default function RegionalMap({ data, onRegionSelect }: RegionalMapProps) {
  const regions = useMemo(
    () => [
      { id: "NCR", name: "National Capital Region" },
      { id: "R1", name: "Ilocos Region" },
      { id: "R2", name: "Cagayan Valley" },
      { id: "R3", name: "Central Luzon" },
      { id: "R4A", name: "CALABARZON" },
      { id: "R4B", name: "MIMAROPA" },
      { id: "R5", name: "Bicol Region" },
      { id: "R6", name: "Western Visayas" },
      { id: "R7", name: "Central Visayas" },
      { id: "R8", name: "Eastern Visayas" },
      { id: "R9", name: "Zamboanga Peninsula" },
      { id: "R10", name: "Northern Mindanao" },
      { id: "R11", name: "Davao Region" },
      { id: "R12", name: "SOCCSKSARGEN" },
      { id: "R13", name: "Caraga" },
      { id: "BARMM", name: "Bangsamoro" },
    ],
    [],
  )

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Regional Investment Map</CardTitle>
        <Map className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <Select
            onValueChange={(value) => {
              const region = data.find((r) => r.id === value)
              if (region) onRegionSelect(region)
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a region" />
            </SelectTrigger>
            <SelectContent>
              {regions.map((region) => (
                <SelectItem key={region.id} value={region.id}>
                  {region.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-4">
          {data.map((region) => (
            <div
              key={region.id}
              className="flex items-center justify-between rounded-lg border p-4 hover:bg-accent"
              role="button"
              onClick={() => onRegionSelect(region)}
            >
              <div>
                <h3 className="font-medium">{region.name}</h3>
                <p className="text-sm text-muted-foreground">GDP Growth: {region.gdpGrowth}%</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">Investment Score: {region.investmentScore}</p>
                <p className="text-sm text-muted-foreground">Labor Force: {region.laborForce.toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

