"use client"

import { Shield } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { RiskAnalysis } from "@/types"

interface RiskAnalysisCardProps {
  data: RiskAnalysis
}

export default function RiskAnalysisCard({ data }: RiskAnalysisCardProps) {
  const getRiskColor = (value: number) => {
    if (value < 30) return "text-green-500"
    if (value < 70) return "text-yellow-500"
    return "text-red-500"
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Risk Analysis</CardTitle>
        <Shield className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <div className="grid gap-4">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <span>Political Risk</span>
                  <span className={getRiskColor(data.political)}>{data.political}%</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <ul className="list-disc pl-4">
                  {data.details.political.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <span>Crime Risk</span>
                  <span className={getRiskColor(data.crime)}>{data.crime}%</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <ul className="list-disc pl-4">
                  {data.details.crime.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <span>Economic Risk</span>
                  <span className={getRiskColor(data.economy)}>{data.economy}%</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <ul className="list-disc pl-4">
                  {data.details.economy.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              </TooltipContent>
            </Tooltip>
          </div>
        </TooltipProvider>
        <div className="mt-4 text-xs text-muted-foreground">
          Last updated: {new Date(data.lastUpdated).toLocaleString()}
        </div>
      </CardContent>
    </Card>
  )
}

