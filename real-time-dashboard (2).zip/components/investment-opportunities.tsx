"use client"

import { Briefcase } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { InvestmentOpportunity } from "@/types"

interface InvestmentOpportunitiesProps {
  opportunities: InvestmentOpportunity[]
  onSelect: (opportunity: InvestmentOpportunity) => void
}

export default function InvestmentOpportunities({ opportunities, onSelect }: InvestmentOpportunitiesProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Investment Opportunities</CardTitle>
        <Briefcase className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Sector</TableHead>
              <TableHead>Region</TableHead>
              <TableHead>Investment (USD)</TableHead>
              <TableHead>Jobs</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {opportunities.map((opportunity) => (
              <TableRow
                key={opportunity.id}
                className="cursor-pointer hover:bg-accent"
                onClick={() => onSelect(opportunity)}
              >
                <TableCell className="font-medium">{opportunity.sector}</TableCell>
                <TableCell>{opportunity.region}</TableCell>
                <TableCell>
                  {opportunity.investmentSize.toLocaleString("en-US", {
                    style: "currency",
                    currency: "USD",
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0,
                  })}
                </TableCell>
                <TableCell>{opportunity.jobsCreated.toLocaleString()}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      opportunity.status === "open"
                        ? "default"
                        : opportunity.status === "pending"
                          ? "secondary"
                          : "outline"
                    }
                  >
                    {opportunity.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

