"use client"

import { useEffect, useState } from "react"
import { Bot } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { BusinessRequirement, MatchResult, RegionalProfile } from "@/types"

interface MatchingEngineProps {
  requirement: BusinessRequirement
  regions: RegionalProfile[]
  onMatchComplete: (matches: MatchResult[]) => void
}

export default function MatchingEngine({ requirement, regions, onMatchComplete }: MatchingEngineProps) {
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState("Initializing matching engine...")

  useEffect(() => {
    const matchRegions = async () => {
      setStatus("Analyzing business requirements...")
      setProgress(20)

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStatus("Evaluating regional profiles...")
      setProgress(40)

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStatus("Calculating match scores...")
      setProgress(60)

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStatus("Ranking potential matches...")
      setProgress(80)

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStatus("Finalizing results...")
      setProgress(100)

      // Calculate matches
      const matches = regions
        .map((region) => {
          const infrastructureScore = calculateInfrastructureScore(requirement, region)
          const workforceScore = calculateWorkforceScore(requirement, region)
          const locationScore = calculateLocationScore(requirement, region)
          const incentivesScore = calculateIncentivesScore(region)

          const totalScore = (infrastructureScore + workforceScore + locationScore + incentivesScore) / 4

          return {
            id: `match-${region.id}`,
            businessId: requirement.id,
            regionId: region.id,
            matchScore: totalScore,
            matchFactors: [
              {
                factor: "Infrastructure",
                score: infrastructureScore,
                details: "Based on available facilities and utilities",
              },
              {
                factor: "Workforce",
                score: workforceScore,
                details: "Based on available skilled and unskilled labor",
              },
              {
                factor: "Location",
                score: locationScore,
                details: "Based on accessibility and market proximity",
              },
              {
                factor: "Incentives",
                score: incentivesScore,
                details: "Based on available government incentives",
              },
            ],
            status: "pending",
            timeline: {
              created: new Date().toISOString(),
            },
            notes: [],
          } as MatchResult
        })
        .sort((a, b) => b.matchScore - a.matchScore)
        .slice(0, 5)

      onMatchComplete(matches)
    }

    matchRegions()
  }, [requirement, regions, onMatchComplete])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          AI Matching Engine
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Progress value={progress} className="h-2" />
        <p className="text-sm text-muted-foreground">{status}</p>
      </CardContent>
    </Card>
  )
}

// Scoring functions
function calculateInfrastructureScore(requirement: BusinessRequirement, region: RegionalProfile): number {
  let score = 0
  const { infrastructureNeeds } = requirement

  if (infrastructureNeeds.power && region.infrastructure.power.available) {
    score += 25
  }
  if (infrastructureNeeds.water && region.infrastructure.water.available) {
    score += 25
  }
  if (infrastructureNeeds.internet && region.infrastructure.internet.available) {
    score += 25
  }
  if (
    infrastructureNeeds.transportation &&
    (region.infrastructure.transportation.airports > 0 || region.infrastructure.transportation.highways > 0)
  ) {
    score += 25
  }

  return score
}

function calculateWorkforceScore(requirement: BusinessRequirement, region: RegionalProfile): number {
  const requiredTotal =
    requirement.workforceNeeds.skilled + requirement.workforceNeeds.unskilled + requirement.workforceNeeds.technical

  const availableTotal = region.workforce.skilled + region.workforce.unskilled + region.workforce.technical

  return Math.min((availableTotal / requiredTotal) * 100, 100)
}

function calculateLocationScore(requirement: BusinessRequirement, region: RegionalProfile): number {
  // Basic location score based on space availability
  let score = 0
  const { spaceRequirement } = requirement

  if (spaceRequirement.type === "land") {
    score = (region.landAvailability.industrial / spaceRequirement.size) * 100
  } else if (spaceRequirement.type === "office") {
    score = (region.landAvailability.commercial / spaceRequirement.size) * 100
  }

  return Math.min(score, 100)
}

function calculateIncentivesScore(region: RegionalProfile): number {
  // Score based on number of incentives
  return Math.min((region.incentives.tax.length + region.incentives.other.length) * 10, 100)
}

