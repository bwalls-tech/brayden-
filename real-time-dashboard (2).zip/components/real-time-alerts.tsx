"use client"

import { Bell } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Alert {
  id: string
  type: string
  message: string
  time: string
}

const alerts: Alert[] = [
  {
    id: "1",
    type: "Market Update",
    message: "PSEi up by 2.3% in morning trading",
    time: "2 mins ago",
  },
  {
    id: "2",
    type: "Currency Alert",
    message: "PHP strengthens against USD",
    time: "5 mins ago",
  },
  {
    id: "3",
    type: "Trading Alert",
    message: "Unusual volume detected in banking sector",
    time: "10 mins ago",
  },
]

export default function RealTimeAlerts() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Real-Time Market Alerts</CardTitle>
        <Bell className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Alert</TableHead>
              <TableHead>Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {alerts.map((alert) => (
              <TableRow key={alert.id}>
                <TableCell className="font-medium">{alert.type}</TableCell>
                <TableCell>{alert.message}</TableCell>
                <TableCell>{alert.time}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

