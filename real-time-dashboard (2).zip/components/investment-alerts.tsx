"use client"

import { AlertTriangle } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { InvestmentAlert } from "@/types"

interface InvestmentAlertsProps {
  alerts: InvestmentAlert[]
}

export default function InvestmentAlerts({ alerts }: InvestmentAlertsProps) {
  // Fallback data if no alerts are provided
  const defaultAlerts: InvestmentAlert[] = [
    {
      id: "1",
      title: "New Investment Opportunity",
      description: "Tech sector showing strong growth potential in NCR",
      severity: "medium",
      timestamp: new Date().toISOString(),
    },
  ]

  const displayAlerts = alerts.length > 0 ? alerts : defaultAlerts

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Investment Alerts</CardTitle>
        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          {displayAlerts.map((alert) => (
            <Alert
              key={alert.id}
              variant={alert.severity === "high" ? "destructive" : alert.severity === "medium" ? "default" : "outline"}
              className="mb-3"
            >
              <AlertTitle>{alert.title}</AlertTitle>
              <AlertDescription>{alert.description}</AlertDescription>
            </Alert>
          ))}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

