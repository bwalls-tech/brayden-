"use client"

import { Shield } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { RiskMetrics } from "@/types"

interface RiskAnalysisProps {
  data: RiskMetrics
}

export default function RiskAnalysis({ data }: RiskAnalysisProps) {
  const getRiskColor = (value: number) => {
    if (value >= 70) return "bg-green-500"
    if (value >= 40) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Risk Analysis</CardTitle>
        <Shield className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Political Stability</span>
                <span className="text-sm text-muted-foreground">{data.political}%</span>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Progress value={data.political} className={getRiskColor(data.political)} />
                </TooltipTrigger>
                <TooltipContent>
                  <ul className="list-disc pl-4">
                    {data.details.political.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </TooltipContent>
              </Tooltip>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Economic Outlook</span>
                <span className="text-sm text-muted-foreground">{data.economic}%</span>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Progress value={data.economic} className={getRiskColor(data.economic)} />
                </TooltipTrigger>
                <TooltipContent>
                  <ul className="list-disc pl-4">
                    {data.details.economic.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </TooltipContent>
              </Tooltip>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Infrastructure</span>
                <span className="text-sm text-muted-foreground">{data.infrastructure}%</span>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Progress value={data.infrastructure} className={getRiskColor(data.infrastructure)} />
                </TooltipTrigger>
                <TooltipContent>
                  <ul className="list-disc pl-4">
                    {data.details.infrastructure.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </TooltipContent>
              </Tooltip>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Workforce Availability</span>
                <span className="text-sm text-muted-foreground">{data.workforce}%</span>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Progress value={data.workforce} className={getRiskColor(data.workforce)} />
                </TooltipTrigger>
                <TooltipContent>
                  <ul className="list-disc pl-4">
                    {data.details.workforce.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
        </TooltipProvider>
      </CardContent>
    </Card>
  )
}

