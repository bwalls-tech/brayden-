"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import type { CompanyRequirement, RegionData } from "@/types"

interface InvestmentMatcherProps {
  regions: RegionData[]
  onMatch: (requirements: CompanyRequirement) => void
}

const initialRequirements: CompanyRequirement = {
  industry: "",
  investmentSize: 100000,
  employmentTarget: 0,
  infrastructureNeeds: [],
  resourceRequirements: [],
  timeline: "",
}

export default function InvestmentMatcher({ regions, onMatch }: InvestmentMatcherProps) {
  const [mounted, setMounted] = useState(false)
  const [requirements, setRequirements] = useState<CompanyRequirement>(initialRequirements)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onMatch(requirements)
  }

  if (!mounted) {
    return null // Prevent hydration mismatch
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Investment Matching System</CardTitle>
        <CardDescription>Enter your requirements to find the perfect investment location</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium">Industry</label>
            <Select
              value={requirements.industry}
              onValueChange={(value) => setRequirements({ ...requirements, industry: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Industry" />
              </SelectTrigger>
              <SelectContent>
                {["Manufacturing", "Technology", "Agriculture", "Tourism", "Energy"].map((industry) => (
                  <SelectItem key={industry} value={industry.toLowerCase()}>
                    {industry}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Investment Size (USD)</label>
            <div className="flex items-center space-x-4">
              <Slider
                min={100000}
                max={10000000}
                step={100000}
                value={[requirements.investmentSize]}
                onValueChange={([value]) => setRequirements({ ...requirements, investmentSize: value })}
              />
              <span className="min-w-[100px] text-right">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                  maximumFractionDigits: 0,
                }).format(requirements.investmentSize)}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Employment Target</label>
            <Input
              type="number"
              min={0}
              value={requirements.employmentTarget}
              onChange={(e) =>
                setRequirements({
                  ...requirements,
                  employmentTarget: Number.parseInt(e.target.value) || 0,
                })
              }
            />
          </div>

          <Separator />

          <div className="flex justify-end">
            <Button type="submit">
              <Search className="mr-2 h-4 w-4" />
              Find Matches
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

